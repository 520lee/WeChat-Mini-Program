var local_database=[
    {
        date: 'sep 18 2016',
        title: '正是虾肥蟹壮时',
        imgSrc: '/images/post/crab.png',
        avatar: '/images/avatar/1.png',
        content: '本文档将带你一步步创建完成一个微信小程序，并可以在手机上体验该小程序的实际效果。这个小程序的首页将会显示欢迎语以及当前用户的微信头像，点击头像',
        reading: '112',
        collection: '96',
        headImgSrc:'/images/post/crab.png',
        author:'李白',
        dataTime:'24time',
        detail:'并可以在手机上体验该小程序的实际效果。',
        postId:1
    },
    {
        //按住alt + shift + f可以格式化代码
        date: 'sep 19 2016',
        title: '正是虾肥蟹壮时',
        imgSrc: '/images/post/bl.png',
        avatar: '/images/avatar/2.png',
        content: '本文档将带你一步步创建完成一个微信小程序，并可以在手机上体验该小程序的实际效果。这个小程序的首页将会显示欢迎语以及当前用户的微信头像，点击头像',
        reading: '112',
        collection: '96',
        headImgSrc:'/images/post/bl.png',
        author:'李白2',
        dataTime:'24time',
        detail:'并可以在手机上体验该小程序的实际效果。',
        postId:2
    },
    {
        //按住alt + shift + f可以格式化代码
        date: 'sep 19 2016',
        title: '正是虾肥蟹壮时',
        imgSrc: '/images/post/cat.png',
        avatar: '/images/avatar/3.png',
        content: '本文档将带你一步步创建完成一个微信小程序，并可以在手机上体验该小程序的实际效果。这个小程序的首页将会显示欢迎语以及当前用户的微信头像，点击头像',
        reading: '112',
        collection: '96',
        headImgSrc:'/images/post/cat.png',
        author:'李白3',
        dataTime:'24time',
        detail:'并可以在手机上体验该小程序的实际效果。',
        postId:3
    },
    {
        //按住alt + shift + f可以格式化代码
        date: 'sep 19 2016',
        title: '正是虾肥蟹壮时',
        imgSrc: '/images/post/vr.png',
        avatar: '/images/avatar/4.png',
        content: '本文档将带你一步步创建完成一个微信小程序，并可以在手机上体验该小程序的实际效果。这个小程序的首页将会显示欢迎语以及当前用户的微信头像，点击头像',
        reading: '112',
        collection: '96',
        headImgSrc:'/images/post/vr.png',
        author:'李白4',
        dataTime:'24time',
        detail:'并可以在手机上体验该小程序的实际效果。',
        postId:4
    },
]
module.exports={
    postList : local_database
}